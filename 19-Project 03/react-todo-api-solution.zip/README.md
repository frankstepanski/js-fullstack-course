# React To-Do App with Local API

This version adds a real REST API using **json-server**, letting you perform full CRUD operations with persistent data.

## 🚀 Run the App

```bash
npm install
npm run dev
```

Runs both:
- Vite → http://localhost:5173
- json-server → http://localhost:3001 (proxied via /api)

## 📦 Features

- React + React Router
- CRUD Todos (GET, POST, PATCH, DELETE)
- Contact form POST to /api/messages
- 10+ custom CSS rules