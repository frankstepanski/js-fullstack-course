import { NavLink } from 'react-router-dom'

export default function Navbar() {
  return (
    <header className="header">
      <h1 className="brand">To‑Do API App</h1>
      <nav>
        <NavLink to="/todos">Todos</NavLink>
        <NavLink to="/contact">Contact</NavLink>
      </nav>
    </header>
  )
}