const BASE = '/api/messages';

export async function sendMessage(data) {
  const res = await fetch(BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...data, ts: Date.now() })
  });
  if (!res.ok) throw new Error('Failed to send message');
  return res.json();
}