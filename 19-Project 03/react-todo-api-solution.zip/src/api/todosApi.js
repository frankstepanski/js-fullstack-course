const BASE = '/api/todos';

export async function getTodos() {
  const res = await fetch(BASE);
  if (!res.ok) throw new Error('Failed to load todos');
  return res.json();
}

export async function addTodo(text) {
  const res = await fetch(BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, completed: false })
  });
  if (!res.ok) throw new Error('Failed to add todo');
  return res.json();
}

export async function toggleTodo(id, completed) {
  const res = await fetch(`${BASE}/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ completed })
  });
  if (!res.ok) throw new Error('Failed to toggle todo');
  return res.json();
}

export async function deleteTodo(id) {
  const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete todo');
  return true;
}