import { useState } from 'react';
import { sendMessage } from '../api/messagesApi';

export default function Contact() {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', comments: '' });
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState(null);

  function onChange(e) {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  }

  async function onSubmit(e) {
    e.preventDefault();
    setStatus('sending');
    try {
      await sendMessage(form);
      setStatus('sent');
      setForm({ firstName: '', lastName: '', email: '', comments: '' });
    } catch (e) {
      setStatus('error');
      setError(e.message);
    }
  }

  return (
    <section className="contact">
      <h2>Contact</h2>
      <form className="col gap" onSubmit={onSubmit}>
        <input name="firstName" placeholder="First Name" value={form.firstName} onChange={onChange} required />
        <input name="lastName" placeholder="Last Name" value={form.lastName} onChange={onChange} />
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={onChange} required />
        <textarea name="comments" rows="4" placeholder="Comments" value={form.comments} onChange={onChange} required />
        <button disabled={status === 'sending'}>{status === 'sending' ? 'Sending...' : 'Send'}</button>
        {status === 'sent' && <p className="success">Message sent!</p>}
        {status === 'error' && <p className="error">{error}</p>}
      </form>
    </section>
  );
}