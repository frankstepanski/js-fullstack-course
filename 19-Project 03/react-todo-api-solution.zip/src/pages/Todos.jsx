import { useEffect, useState } from 'react';
import { getTodos, addTodo, toggleTodo, deleteTodo } from '../api/todosApi';

const FILTERS = {
  all: () => true,
  active: (t) => !t.completed,
  completed: (t) => t.completed
};

export default function Todos() {
  const [todos, setTodos] = useState([]);
  const [newText, setNewText] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let ignore = false;
    async function load() {
      try {
        const data = await getTodos();
        if (!ignore) setTodos(data);
      } catch (e) {
        if (!ignore) setErr(e.message);
      } finally {
        if (!ignore) setLoading(false);
      }
    }
    load();
    return () => { ignore = true };
  }, []);

  async function handleAdd(e) {
    e.preventDefault();
    if (!newText.trim()) return;
    try {
      const created = await addTodo(newText.trim());
      setTodos(prev => [created, ...prev]);
      setNewText('');
    } catch (e) {
      setErr(e.message);
    }
  }

  async function handleToggle(todo) {
    try {
      const updated = await toggleTodo(todo.id, !todo.completed);
      setTodos(prev => prev.map(t => t.id === todo.id ? updated : t));
    } catch (e) {
      setErr(e.message);
    }
  }

  async function handleDelete(id) {
    try {
      await deleteTodo(id);
      setTodos(prev => prev.filter(t => t.id !== id));
    } catch (e) {
      setErr(e.message);
    }
  }

  const visible = todos.filter(FILTERS[filter]);

  return (
    <section className="todos">
      <h2>Todos</h2>
      <form onSubmit={handleAdd} className="row gap">
        <input
          type="text"
          placeholder="Add a new task..."
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
        />
        <button type="submit">Add</button>
      </form>

      <div className="filters">
        {['all', 'active', 'completed'].map(f => (
          <button key={f} className={filter === f ? 'active' : ''} onClick={() => setFilter(f)}>
            {f}
          </button>
        ))}
      </div>

      {loading && <p>Loading...</p>}
      {err && <p className="error">{err}</p>}

      <ul className="todo-list">
        {visible.map(t => (
          <li key={t.id} className={t.completed ? 'done' : ''}>
            <label>
              <input
                type="checkbox"
                checked={t.completed}
                onChange={() => handleToggle(t)}
              />
              {t.text}
            </label>
            <button onClick={() => handleDelete(t.id)}>✕</button>
          </li>
        ))}
      </ul>
    </section>
  );
}