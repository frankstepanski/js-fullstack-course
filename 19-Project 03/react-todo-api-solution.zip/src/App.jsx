import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Todos from './pages/Todos.jsx'
import Contact from './pages/Contact.jsx'

export default function App() {
  return (
    <div className="container">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Navigate to="/todos" replace />} />
          <Route path="/todos" element={<Todos />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<h2>404 — Not Found</h2>} />
        </Routes>
      </main>
    </div>
  )
}