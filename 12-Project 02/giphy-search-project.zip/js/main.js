// Giphy Search Engine - Vanilla JS
// -----------------------------------------------------------
// 🔑 API Key handling
// Set YOUR key once in the console to avoid committing secrets:
//   localStorage.setItem('GIPHY_API_KEY', 'YOUR_KEY_HERE')
// -----------------------------------------------------------

const API_KEY = localStorage.getItem('GIPHY_API_KEY') || 'YOUR_GIPHY_API_KEY_HERE';
const BASE_URL = 'https://api.giphy.com/v1/gifs/search';

// DOM references
const form = document.getElementById('search-form');
const queryInput = document.getElementById('query');
const ratingSelect = document.getElementById('rating');
const limitSelect = document.getElementById('limit');
const grid = document.getElementById('grid');
const feedback = document.getElementById('feedback');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const pageInfo = document.getElementById('pageInfo');
const cardTpl = document.getElementById('gif-card-template');

// State
let state = {
  q: '',
  rating: '',
  limit: 24,
  offset: 0,
  totalCount: 0
};

function setBusy(isBusy) {
  grid.setAttribute('aria-busy', String(isBusy));
}

function showFeedback(message, type = 'info') {
  feedback.hidden = false;
  feedback.textContent = message;
  feedback.className = `feedback ${type}`;
}

function clearFeedback() {
  feedback.hidden = true;
  feedback.textContent = '';
  feedback.className = 'feedback';
}

function clearGrid() {
  grid.innerHTML = '';
}

function buildUrl() {
  const params = new URLSearchParams();
  params.set('api_key', API_KEY);
  params.set('q', state.q);
  params.set('limit', state.limit);
  params.set('offset', state.offset);
  if (state.rating) params.set('rating', state.rating);
  params.set('lang', 'en');
  return `${BASE_URL}?${params.toString()}`;
}

async function search() {
  if (!API_KEY || API_KEY === 'YOUR_GIPHY_API_KEY_HERE') {
    showFeedback('Missing API key. Add it via DevTools: localStorage.setItem("GIPHY_API_KEY","YOUR_KEY")', 'warn');
    return;
  }

  setBusy(true);
  clearFeedback();

  try {
    const url = buildUrl();
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const json = await res.json();
    state.totalCount = json.pagination?.total_count ?? 0;
    renderResults(json.data || []);
    updatePager();
  } catch (err) {
    console.error(err);
    showFeedback(`Unable to load results: ${err.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

function renderResults(items) {
  clearGrid();

  if (!items.length) {
    showFeedback('No results. Try a different search term.', 'info');
    return;
  }

  const frag = document.createDocumentFragment();

  for (const gif of items) {
    const card = cardTpl.content.firstElementChild.cloneNode(true);
    const img = card.querySelector('.thumb');
    const caption = card.querySelector('.caption');

    // Prefer lightweight webp if available; fallback to downsized
    const images = gif.images || {};
    const best =
      images.fixed_width_webp ||
      images.fixed_width ||
      images.downsized_medium ||
      images.original;

    img.src = best?.url || best?.webp || '';
    img.alt = gif.title || 'GIF';
    caption.textContent = gif.title || 'Untitled';

    frag.appendChild(card);
  }

  grid.appendChild(frag);
}

function updatePager() {
  const currentPage = Math.floor(state.offset / state.limit) + 1;
  const totalPages = Math.max(1, Math.ceil(state.totalCount / state.limit));
  pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;

  prevBtn.disabled = state.offset <= 0;
  nextBtn.disabled = state.offset + state.limit >= state.totalCount;
}

// Event handlers
form.addEventListener('submit', (e) => {
  e.preventDefault();
  state.q = (queryInput.value || '').trim();
  state.rating = ratingSelect.value;
  state.limit = Number(limitSelect.value);
  state.offset = 0;
  if (!state.q) {
    showFeedback('Please enter a search term.', 'warn');
    return;
  }
  search();
});

prevBtn.addEventListener('click', () => {
  state.offset = Math.max(0, state.offset - state.limit);
  search();
});

nextBtn.addEventListener('click', () => {
  state.offset = state.offset + state.limit;
  search();
});

// Initial UI
updatePager();
showFeedback('Enter a term and click Search to load GIFs.');
