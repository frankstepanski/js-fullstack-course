# Giphy Search Engine

A simple, responsive GIF search app powered by the **Giphy API**, built with **HTML, CSS, and JavaScript** (no frameworks).

## Features
- Search GIFs by keyword
- Rating & page size controls
- Responsive CSS grid layout
- Pagination with offset handling
- Accessible markup (aria-live updates, labels, keyboard friendly)
- No secrets committed — API key is read from `localStorage`

## Getting Started
1. Open **DevTools Console** and add your API key (from https://developers.giphy.com/):
   ```js
   localStorage.setItem('GIPHY_API_KEY','YOUR_KEY_HERE');
   ```
2. Open `index.html` with a local server (e.g., VS Code **Live Server**).
3. Search for GIFs!

## Project Structure
```
/giphy-search-project
├── index.html
├── /css
│   └── style.css
└── /js
    └── main.js
```

## Notes
- For demo purposes, the script will warn you if the API key is missing.
- You can replace the placeholder with an environment-based approach in a real build setup.
